# DM GULLY CRICKET — Android starter project

This is the first runnable Android Studio source project for the DM GULLY CRICKET scoring app.

## Included in this starter
- Premium dark navy and gold interface
- English, Hindi and Odia language selector (initial UI labels; full localization is a follow-up)
- T5, T10, T15, T20, ODI, Test and custom-over format selector
- Basic local innings scoring: 0, 1, 2, 3, 4, 6, Wide +1, wicket, undo and reset
- Run rate and over counter

## Important limitations
This is a first local prototype, not yet a public live-score product:
- Scores are held in app memory and reset when the app process is closed.
- Admin authentication, Firebase cloud sync, public spectator screens, full extras/no-ball rules, strike rotation, innings/target handling, scorecards, player statistics and tournament tables are not implemented yet.
- The Wide +1 and Wicket buttons are deliberately simplified placeholders; proper cricket scoring rules will be implemented in the next version.
- No signed APK/AAB is included.

## Open on Android
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `DM_GULLY_CRICKET` folder.
4. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
5. Run the `app` configuration on an Android device or emulator.

An Android phone alone cannot reliably build/sign this project using standard Android Studio. You can keep the ZIP on your phone, then open it on a computer for building.

## Next development stage
Connect Firebase Authentication and Realtime Database, add role-based admin access, and publish live match updates to a read-only public match screen. Never put Firebase service-account keys or admin secrets in the Android app.
