package com.dmgullycricket.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Gold = Color(0xFFE5B94F)
private val Navy = Color(0xFF0B1220)
private val Panel = Color(0xFF172235)
private val White = Color(0xFFF7F7F7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DMGullyCricketApp() }
    }
}

@Composable
fun DMGullyCricketApp() {
    var language by remember { mutableStateOf("English") }
    var format by remember { mutableStateOf("T20") }
    var customOvers by remember { mutableStateOf("8") }
    var teamA by remember { mutableStateOf("DM POWER HITTER") }
    var teamB by remember { mutableStateOf("MAHAKAL 11") }
    var runs by remember { mutableIntStateOf(0) }
    var wickets by remember { mutableIntStateOf(0) }
    var balls by remember { mutableIntStateOf(0) }
    var inningsStarted by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(listOf<Triple<Int, Int, Int>>()) }

    val maxOvers = when (format) {
        "T5" -> 5
        "T10" -> 10
        "T15" -> 15
        "T20" -> 20
        "ODI" -> 50
        "Test" -> 90
        else -> customOvers.toIntOrNull()?.coerceIn(1, 90) ?: 8
    }
    val maxBalls = maxOvers * 6
    val overText = "${balls / 6}.${balls % 6}"
    val title = when (language) {
        "Hindi" -> "डीएम गली क्रिकेट"
        "Odia" -> "ଡିଏମ୍ ଗଲି କ୍ରିକେଟ୍"
        else -> "DM GULLY CRICKET"
    }
    val scoreLabel = when (language) {
        "Hindi" -> "लाइव स्कोर"
        "Odia" -> "ଲାଇଭ୍ ସ୍କୋର"
        else -> "LIVE SCORE"
    }
    val oversLabel = when (language) {
        "Hindi" -> "ओवर"
        "Odia" -> "ଓଭର"
        else -> "OVERS"
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, secondary = Gold, background = Navy,
        surface = Panel, onPrimary = Navy, onBackground = White,
        onSurface = White
    )) {
        Column(
            modifier = Modifier.fillMaxSize().background(Navy)
                .verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text("🏏", fontSize = 34.sp)
                Text(title, color = Gold, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                Text("PROFESSIONAL CRICKET SCORING", color = White.copy(alpha = .75f), fontSize = 11.sp)
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("APP SETTINGS", color = Gold, fontWeight = FontWeight.Bold)
                    Text("Language / भाषा / ଭାଷା", color = White)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("English", "Hindi", "Odia").forEach {
                            FilterChip(selected = language == it, onClick = { language = it }, label = { Text(it) })
                        }
                    }
                    Text("Match format", color = White)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("T5", "T10", "T15", "T20", "ODI", "Test", "Custom").forEach {
                            FilterChip(selected = format == it, onClick = { format = it }, label = { Text(it) })
                        }
                    }
                    if (format == "Custom") {
                        OutlinedTextField(
                            value = customOvers, onValueChange = { customOvers = it.filter(Char::isDigit).take(2) },
                            label = { Text("Custom overs (1–90)") }, singleLine = true
                        )
                    }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(scoreLabel, color = Gold, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("$runs/$wickets", color = White, fontSize = 48.sp, fontWeight = FontWeight.ExtraBold)
                    Text("$oversLabel: $overText / $maxOvers", color = White.copy(alpha = .8f), fontSize = 17.sp)
                    Text("Run rate: ${if (balls == 0) "0.00" else "%.2f".format(runs / (balls / 6.0))}", color = Gold)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(value = teamA, onValueChange = { teamA = it }, label = { Text("Batting team") }, singleLine = true)
                    OutlinedTextField(value = teamB, onValueChange = { teamB = it }, label = { Text("Bowling team") }, singleLine = true)
                }
            }

            Text("SCORING CONTROLS", color = Gold, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                listOf(0, 1, 2, 3, 4, 6).forEach { value ->
                    Button(
                        onClick = {
                            if (inningsStarted && balls < maxBalls && wickets < 10) {
                                history = history + Triple(runs, wickets, balls)
                                runs += value
                                balls++
                            }
                        },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (value == 4 || value == 6) Gold else Panel)
                    ) { Text("$value", color = if (value == 4 || value == 6) Navy else White, fontWeight = FontWeight.Bold) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = {
                    if (inningsStarted && balls < maxBalls && wickets < 10) {
                        history = history + Triple(runs, wickets, balls)
                        runs += 1; balls++
                    }
                }, modifier = Modifier.weight(1f)) { Text("Wide +1") }
                Button(onClick = {
                    if (inningsStarted && balls < maxBalls && wickets < 10) {
                        history = history + Triple(runs, wickets, balls)
                        runs += 1; wickets++; balls++
                    }
                }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9D3434))) {
                    Text("Wicket")
                }
                OutlinedButton(onClick = {
                    val last = history.lastOrNull()
                    if (last != null) {
                        runs = last.first; wickets = last.second; balls = last.third
                        history = history.dropLast(1)
                    }
                }, modifier = Modifier.weight(1f)) { Text("Undo") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = { inningsStarted = true }, modifier = Modifier.weight(1f)) {
                    Text(if (inningsStarted) "Innings Running" else "Start Innings")
                }
                OutlinedButton(onClick = {
                    runs = 0; wickets = 0; balls = 0; history = emptyList(); inningsStarted = false
                }, modifier = Modifier.weight(1f)) { Text("Reset") }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Text("MATCH STATUS", color = Gold, fontWeight = FontWeight.Bold)
                    Text(
                        when {
                            wickets >= 10 -> "All out"
                            balls >= maxBalls -> "Overs completed"
                            !inningsStarted -> "Ready to start"
                            else -> "Innings in progress"
                        },
                        color = White
                    )
                    Text("This first version stores the score only while the app is open. Cloud live sharing and admin accounts are the next development stage.", color = White.copy(alpha = .7f), fontSize = 12.sp)
                }
            }
            Text("DM GULLY CRICKET • VERSION 1.0", color = Gold.copy(alpha = .8f), fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}
